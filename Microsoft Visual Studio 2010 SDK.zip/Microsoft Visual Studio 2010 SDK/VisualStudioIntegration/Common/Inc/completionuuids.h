#pragma once

#define uuid_IVsCommandWindowCompletion          34896BBB-A3D5-4c80-BCCE-E9271BEEDC11
#define uuid_IVsImmediateStatementCompletion     5CE7AE60-7B66-4301-8892-90BC0B49A89B
#define uuid_IVsImmediateStatementCompletion2    58F03D6E-F781-4e44-BD88-3BDE817CBDCD
