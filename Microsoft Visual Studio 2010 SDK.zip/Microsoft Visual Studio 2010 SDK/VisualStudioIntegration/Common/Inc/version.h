#define rmj 10
#define rmm 0
#define rup 30319
#define rpt 1
#define szVerName ""
#define szVerUser "VSBLD305"
