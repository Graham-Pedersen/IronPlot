#pragma once

//                                                new                                     old
#define uuid_IVsUserContext                     761081DF-D45F-4683-9B9E-1B7241E56F5C //3c1f59c0-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsUserContextUpdate               F5ED7D1C-61B6-428A-8129-E13B36D9E9A7 //3c1f59c1-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsProvideUserContext              997D7904-D948-4C8B-8BAB-0BDA1E212F6E //3c1f59ca-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsProvideUserContextForObject     F98CCC8A-9C5F-41EB-8421-711C0F1880E6 //3c1f59cb-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsUserContextItemCollection       2A6DE4A2-5B3D-46EB-A65C-24C4EF4F396F //3c1f59c2-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsUserContextItem                 720B8500-17B3-4C89-AE84-2CFE7251B4B8 //3c1f59c3-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsHelpAttributeList               0A56FB1E-1B2F-4699-8178-63B98E816F35
#define uuid_IVsMonitorUserContext              9C074FDB-3D7D-4512-9604-72B3B0A5F609 //3c1f59c4-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsUserContextItemProvider         715C98B7-05FB-4A1A-86C8-FF00CE2E5D64 //3c1f59c7-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsUserContextItemEvents           A2078F0E-A310-420A-BA27-16531905B88F //3c1f59c8-69cf-11d2-aa7c-00c04f990343
#define uuid_IVsUserContextCustomize            0F817159-761D-447e-9600-4C3387F4C0FD
// library
#define uuid_lib_VsContext                      9E9C5B7E-02B2-41B5-8D81-DF773C10D0BE //3c1f59c5-69cf-11d2-aa7c-00c04f990343
#define uuid_coclass_VsContextClass           /*B531C14D-AFD7-4C68-8CD5-93F65EEB6A08*/ 3c1f59c6-69cf-11d2-aa7c-00c04f990343


//For context2.idl
#define uuid_IVsUserContextExport               B50F15A4-C42D-4dc1-AE09-7D2069EC58E9

