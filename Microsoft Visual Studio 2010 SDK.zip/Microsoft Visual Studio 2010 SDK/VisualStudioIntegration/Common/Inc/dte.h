/*****************************************************************************
*  dte.h
*
*  Copyright (C) 1995-2000, Microsoft Corporation.  All Rights Reserved.
*
******************************************************************************/

namespace VxDTE
{
    #include "dteinternal.h"
};

#ifndef FORCE_EXPLICIT_DTE_NAMESPACE
using namespace VxDTE;
#endif
