//----------------------------------------------------------------------------
//
//  Microsoft IStudio
//
//  Copyright 1997 Microsoft Corporation.  All Rights Reserved.
//
//  File:	ocundoid.h
//
//  Contents:
//		OleUndoManager GUIDs
//----------------------------------------------------------------------------
#ifndef _OCUNDOID_H
#define _OCUNDOID_H

// {C964830F-91A0-11D0-B14C-0000F8041356}
DEFINE_GUID(CLSID_OleUndoManager,
	0xC964830F,0x91A0,0x11D0,0xB1,0x4C,0x00,0x00,0xF8,0x04,0x13,0x56);

#endif //_OCUNDOID_H
