#ifndef MSO96TL_H
#define MSO96TL_H

#pragma message ("Mso96TL.h file is obsolete.  Including MsoTL.h instead.")

#include <msotl.h>

#endif
